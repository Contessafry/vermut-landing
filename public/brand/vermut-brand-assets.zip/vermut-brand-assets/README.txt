Vermut brand assets
- icon/: app icon (light background is primary; dark variant included), SVG + 1024 px PNG
- lockup/: horizontal and stacked lockups (colour on light/dark, black, white)
- wordmark/: Bricolage Grotesque wordmark, outlined
Brand red #CE003E is for marketing; don't recolour or redraw the mark.
"Vermut" and the bottle mark identify the Vermut project; please don't use them to imply endorsement.
